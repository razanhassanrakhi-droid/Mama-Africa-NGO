@extends('admin.layouts.app')

@section('title', __('massage.form_edit_user') ?? 'Edit System User')
@section('header', __('massage.form_edit_user') ?? 'Edit System User')

@section('content')
<div class="bg-white p-6 md:p-8 rounded-xl shadow-sm border border-gray-200 focus-within:ring-2 focus-within:ring-blue-100 transition-all max-w-3xl mx-auto">
    <div class="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
        <h3 class="text-xl font-bold text-gray-800">{{ __('massage.form_edit_user_details') ?? 'Edit User Details' }}</h3>
        <a href="{{ route('admin.users.index') }}" class="text-gray-500 hover:text-blue-600 transition-colors flex items-center gap-1">
            <i class="fas {{ app()->getLocale() == 'ar' ? 'fa-arrow-right' : 'fa-arrow-left' }}"></i> <span>{{ __('massage.form_back_to_list') }}</span>
        </a>
    </div>

    <form action="{{ route('admin.users.update', $user->id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="space-y-6">
            <!-- Name -->
            <div class="bg-gray-50 p-4 rounded-lg border border-gray-100">
                <h4 class="font-semibold text-gray-700 mb-4 border-b pb-2"><i class="fas fa-id-card {{ app()->getLocale() == 'ar' ? 'ml-2' : 'mr-2' }}"></i> {{ __('massage.dt_name') ?? 'Name' }}</h4>
                <div>
                    <input type="text" name="name" value="{{ old('name', $user->name) }}" required class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
                </div>
            </div>

            <!-- Email -->
            <div class="bg-gray-50 p-4 rounded-lg border border-gray-100">
                <h4 class="font-semibold text-gray-700 mb-4 border-b pb-2"><i class="fas fa-envelope {{ app()->getLocale() == 'ar' ? 'ml-2' : 'mr-2' }}"></i> {{ __('massage.dt_email') ?? 'Email Address' }}</h4>
                <div>
                    <input type="email" name="email" value="{{ old('email', $user->email) }}" required dir="ltr" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white {{ app()->getLocale() == 'ar' ? 'text-right' : 'text-left' }}">
                </div>
            </div>

            <!-- Security Questions -->
            <div class="bg-gray-50 p-4 rounded-lg border border-gray-100">
                <h4 class="font-semibold text-gray-700 mb-4 border-b pb-2"><i class="fas fa-shield-alt {{ app()->getLocale() == 'ar' ? 'ml-2' : 'mr-2' }}"></i> {{ __('massage.security_verification') ?? 'Security Verification' }} <span class="text-sm font-normal text-gray-500">({{ __('massage.form_leave_blank') ?? 'Leave blank to keep current' }})</span></h4>
                <div class="space-y-6">
                    
                    <!-- Question 1 -->
                    <div class="pl-4 border-{{ app()->getLocale() == 'ar' ? 'r' : 'l' }}-4 border-blue-400 space-y-4">
                        <div>
                            <label class="block text-sm font-semibold mb-1 text-gray-600">{{ __('massage.security_question_1') ?? 'Security Question 1' }}</label>
                            <select name="security_question" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
                                <option value="">{{ app()->getLocale() == 'ar' ? '-- بدون تغيير --' : '-- No Change --' }}</option>
                                @foreach(__('massage.questions') as $key => $question)
                                    <option value="{{ $key }}" {{ old('security_question', $user->security_question) == $key ? 'selected' : '' }}>{{ $question }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1 text-gray-600">{{ __('massage.security_answer_1') ?? 'Answer 1' }}</label>
                            <input type="text" name="security_answer" placeholder="{{ app()->getLocale() == 'ar' ? 'أدخل إجابة جديدة أو اتركها فارغة' : 'Enter new answer to update' }}" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white {{ app()->getLocale() == 'ar' ? 'text-right' : 'text-left' }}" autocomplete="off">
                        </div>
                    </div>

                    <!-- Question 2 -->
                    <div class="pl-4 border-{{ app()->getLocale() == 'ar' ? 'r' : 'l' }}-4 border-blue-400 space-y-4">
                        <div>
                            <label class="block text-sm font-semibold mb-1 text-gray-600">{{ __('massage.security_question_2') ?? 'Security Question 2' }}</label>
                            <select name="security_question_2" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
                                <option value="">{{ app()->getLocale() == 'ar' ? '-- بدون تغيير --' : '-- No Change --' }}</option>
                                @foreach(__('massage.questions') as $key => $question)
                                    <option value="{{ $key }}" {{ old('security_question_2', $user->security_question_2) == $key ? 'selected' : '' }}>{{ $question }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1 text-gray-600">{{ __('massage.security_answer_2') ?? 'Answer 2' }}</label>
                            <input type="text" name="security_answer_2" placeholder="{{ app()->getLocale() == 'ar' ? 'أدخل إجابة جديدة أو اتركها فارغة' : 'Enter new answer to update' }}" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white {{ app()->getLocale() == 'ar' ? 'text-right' : 'text-left' }}" autocomplete="off">
                        </div>
                    </div>

                    <!-- Question 3 -->
                    <div class="pl-4 border-{{ app()->getLocale() == 'ar' ? 'r' : 'l' }}-4 border-blue-400 space-y-4">
                        <div>
                            <label class="block text-sm font-semibold mb-1 text-gray-600">{{ __('massage.security_question_3') ?? 'Security Question 3' }}</label>
                            <select name="security_question_3" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
                                <option value="">{{ app()->getLocale() == 'ar' ? '-- بدون تغيير --' : '-- No Change --' }}</option>
                                @foreach(__('massage.questions') as $key => $question)
                                    <option value="{{ $key }}" {{ old('security_question_3', $user->security_question_3) == $key ? 'selected' : '' }}>{{ $question }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1 text-gray-600">{{ __('massage.security_answer_3') ?? 'Answer 3' }}</label>
                            <input type="text" name="security_answer_3" placeholder="{{ app()->getLocale() == 'ar' ? 'أدخل إجابة جديدة أو اتركها فارغة' : 'Enter new answer to update' }}" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white {{ app()->getLocale() == 'ar' ? 'text-right' : 'text-left' }}" autocomplete="off">
                        </div>
                    </div>
                    
                </div>
            </div>

            <!-- Password -->
            <div class="bg-gray-50 p-4 rounded-lg border border-gray-100">
                <h4 class="font-semibold text-gray-700 mb-4 border-b pb-2"><i class="fas fa-lock {{ app()->getLocale() == 'ar' ? 'ml-2' : 'mr-2' }}"></i> {{ __('massage.form_change_password') ?? 'Change Password' }} <span class="text-sm font-normal text-gray-500">({{ __('massage.form_leave_blank') ?? 'Leave blank to keep current' }})</span></h4>
                <div class="space-y-4">
                    <!-- Old Password Form Row -->
                    <!-- Old Password Form Row (Employee Only) -->
                    @if(auth()->user()->isEmployee())
                    <div>
                        <label class="block text-sm font-semibold mb-1 text-gray-600">{{ __('massage.form_old_password') ?? 'Old Password' }} <span class="text-xs font-normal text-gray-500">({{ __('massage.form_required_for_change') ?? 'Required to change password' }})</span></label>
                        <div class="relative">
                            <input type="password" id="old_password" name="old_password" dir="ltr" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white {{ app()->getLocale() == 'ar' ? 'text-right pl-10' : 'text-left pr-10' }} @error('old_password') border-red-500 @enderror">
                            <button type="button" onclick="togglePasswordVisibility('old_password')" class="absolute inset-y-0 {{ app()->getLocale() == 'ar' ? 'left-0 pl-3' : 'right-0 pr-3' }} flex items-center text-gray-400 hover:text-blue-600 focus:outline-none transition-colors">
                                <i class="fas fa-eye" id="old_password-eye"></i>
                            </button>
                        </div>
                         @error('old_password')
                            <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                        @enderror
                    </div>
                    @endif

                    <div>
                        <label class="block text-sm font-semibold mb-1 text-gray-600">{{ __('massage.form_new_password') ?? 'New Password' }}</label>
                        <div class="relative">
                            <input type="password" id="password" name="password" dir="ltr" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white {{ app()->getLocale() == 'ar' ? 'text-right pl-10' : 'text-left pr-10' }}">
                            <button type="button" onclick="togglePasswordVisibility('password')" class="absolute inset-y-0 {{ app()->getLocale() == 'ar' ? 'left-0 pl-3' : 'right-0 pr-3' }} flex items-center text-gray-400 hover:text-blue-600 focus:outline-none transition-colors">
                                <i class="fas fa-eye" id="password-eye"></i>
                            </button>
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold mb-1 text-gray-600">{{ __('massage.form_confirm_password') ?? 'Confirm Password' }}</label>
                        <div class="relative">
                            <input type="password" id="password_confirmation" name="password_confirmation" dir="ltr" class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white {{ app()->getLocale() == 'ar' ? 'text-right pl-10' : 'text-left pr-10' }}">
                            <button type="button" onclick="togglePasswordVisibility('password_confirmation')" class="absolute inset-y-0 {{ app()->getLocale() == 'ar' ? 'left-0 pl-3' : 'right-0 pr-3' }} flex items-center text-gray-400 hover:text-blue-600 focus:outline-none transition-colors">
                                <i class="fas fa-eye" id="password_confirmation-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            @if(auth()->user()->isAdmin())
            <!-- Role -->
            <div class="bg-gray-50 p-4 rounded-lg border border-gray-100">
                <h4 class="font-semibold text-gray-700 mb-4 border-b pb-2"><i class="fas fa-id-badge {{ app()->getLocale() == 'ar' ? 'ml-2' : 'mr-2' }}"></i> {{ __('massage.user_role') ?? 'User Role' }}</h4>
                <div>
                    <select name="role" required class="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
                        <option value="admin" {{ old('role', $user->role) == 'admin' ? 'selected' : '' }}>{{ __('massage.role_admin') ?? 'Admin (Full Access)' }}</option>
                        <option value="employee" {{ old('role', $user->role) == 'employee' ? 'selected' : '' }}>{{ __('massage.role_employee') ?? 'Employee (Content Only)' }}</option>
                    </select>
                </div>
            </div>
            @endif

            <div class="mt-8 pt-4 border-t border-gray-100">
                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 px-6 rounded-xl shadow-md transition flex justify-center items-center gap-2">
                    <i class="fas fa-save"></i> <span>{{ __('massage.form_update_user') ?? 'Update User' }}</span>
                </button>
            </div>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
function togglePasswordVisibility(fieldId) {
    const field = document.getElementById(fieldId);
    const icon = document.getElementById(fieldId + '-eye');
    
    if (field.type === 'password') {
        field.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        field.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>
@endpush
